#define IDR_VERSION	001
#define IDI_ICON	100
